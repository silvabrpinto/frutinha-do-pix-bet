import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Mail, Lock, Eye, EyeOff } from 'lucide-react';

const Login = ({ onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) return;
    
    setIsLoading(true);
    
    // Simular delay de autenticação
    setTimeout(() => {
      // Salvar dados do usuário no localStorage
      localStorage.setItem('666bet_user', JSON.stringify({
        email,
        loginTime: new Date().toISOString()
      }));
      
      setIsLoading(false);
      onLogin(email);
    }, 1500);
  };

  return (
    <div className="casino-bg min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <h1 className="text-6xl font-bold neon-text mb-2">666</h1>
          <h2 className="text-3xl font-bold text-white">BET</h2>
          <p className="text-gray-400 mt-2">Cassino Online Premium</p>
        </div>

        {/* Card de Login */}
        <Card className="casino-card border-2 border-blue-500/30 neon-glow">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-white">
              Entrar na Conta
            </CardTitle>
            <p className="text-gray-400">
              Acesse sua conta para começar a jogar
            </p>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Campo Email */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">
                  E-mail
                </label>
                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    type="email"
                    placeholder="seu@email.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="casino-input pl-10 h-12"
                    required
                  />
                </div>
              </div>

              {/* Campo Senha */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-300">
                  Senha
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="casino-input pl-10 pr-10 h-12"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Botão de Login */}
              <Button
                type="submit"
                disabled={isLoading || !email || !password}
                className="casino-button w-full h-12 text-lg font-bold"
              >
                {isLoading ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                    <span>Entrando...</span>
                  </div>
                ) : (
                  'ENTRAR'
                )}
              </Button>
            </form>

            {/* Links adicionais */}
            <div className="mt-6 text-center space-y-2">
              <p className="text-sm text-gray-400">
                Não tem uma conta?{' '}
                <button className="text-blue-400 hover:text-blue-300 font-medium">
                  Criar conta
                </button>
              </p>
              <button className="text-sm text-gray-400 hover:text-gray-300">
                Esqueceu a senha?
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Informações de segurança */}
        <div className="mt-6 text-center">
          <p className="text-xs text-gray-500">
            🔒 Conexão segura e criptografada
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;

