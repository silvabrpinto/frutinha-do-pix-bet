import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { ArrowLeft, Copy, CheckCircle, CreditCard, QrCode } from 'lucide-react';

const DepositScreen = ({ onBack }) => {
  const [copied, setCopied] = useState(false);
  const [depositConfirmed, setDepositConfirmed] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);

  const pixKey = "442.802.418-56";
  const minDeposit = 5;

  const copyPixKey = async () => {
    try {
      await navigator.clipboard.writeText(pixKey);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      // Fallback para navegadores que não suportam clipboard API
      const textArea = document.createElement('textarea');
      textArea.value = pixKey;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const confirmDeposit = () => {
    setIsProcessing(true);
    
    setTimeout(() => {
      // Adicionar 10 moedas ao saldo
      const savedData = localStorage.getItem('666bet_gamedata');
      let gameData = { coins: 0, totalWinnings: 0, spinCount: 0 };
      
      if (savedData) {
        gameData = JSON.parse(savedData);
      }
      
      gameData.coins += 10;
      gameData.lastDeposit = new Date().toISOString();
      
      localStorage.setItem('666bet_gamedata', JSON.stringify(gameData));
      
      setIsProcessing(false);
      setDepositConfirmed(true);
      
      // Voltar para o jogo após 3 segundos
      setTimeout(() => {
        onBack();
      }, 3000);
    }, 2000);
  };

  if (depositConfirmed) {
    return (
      <div className="casino-bg min-h-screen flex items-center justify-center p-4">
        <Card className="casino-card w-full max-w-md text-center">
          <CardContent className="p-8">
            <CheckCircle className="w-16 h-16 text-green-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-white mb-2">Depósito Confirmado!</h2>
            <p className="text-gray-300 mb-4">
              10 moedas foram adicionadas à sua conta
            </p>
            <div className="bg-green-500/20 border border-green-500/50 rounded-lg p-4 mb-4">
              <p className="text-green-400 font-semibold">+10 Moedas</p>
              <p className="text-sm text-gray-300">Agora você pode fazer 10 giros!</p>
            </div>
            <p className="text-sm text-gray-400">
              Redirecionando para o jogo...
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="casino-bg min-h-screen">
      {/* Header */}
      <div className="bg-black/50 backdrop-blur-sm border-b border-blue-500/30 p-4">
        <div className="max-w-4xl mx-auto flex items-center">
          <Button
            onClick={onBack}
            variant="ghost"
            size="sm"
            className="text-white hover:text-blue-400 mr-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold neon-text">Depósito via Pix</h1>
        </div>
      </div>

      {/* Conteúdo */}
      <div className="max-w-4xl mx-auto p-4 pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Instruções */}
          <div>
            <Card className="casino-card mb-6">
              <CardHeader>
                <CardTitle className="text-white flex items-center">
                  <CreditCard className="w-6 h-6 mr-2 text-blue-400" />
                  Como Depositar
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">1</div>
                  <div>
                    <p className="text-white font-semibold">Copie a chave Pix</p>
                    <p className="text-gray-400 text-sm">Use o botão ao lado para copiar nossa chave Pix</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">2</div>
                  <div>
                    <p className="text-white font-semibold">Faça o Pix</p>
                    <p className="text-gray-400 text-sm">Abra seu banco e envie R$ 5,00 ou mais</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="bg-blue-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">3</div>
                  <div>
                    <p className="text-white font-semibold">Confirme o depósito</p>
                    <p className="text-gray-400 text-sm">Clique em "Confirmar Depósito" após enviar</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">4</div>
                  <div>
                    <p className="text-white font-semibold">Receba suas moedas</p>
                    <p className="text-gray-400 text-sm">10 moedas serão creditadas instantaneamente</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Informações importantes */}
            <Card className="casino-card">
              <CardContent className="p-6">
                <h3 className="text-white font-semibold mb-3">⚠️ Informações Importantes</h3>
                <ul className="space-y-2 text-sm text-gray-300">
                  <li>• Depósito mínimo: R$ 5,00</li>
                  <li>• Cada depósito de R$ 5,00 = 10 moedas</li>
                  <li>• Processamento instantâneo</li>
                  <li>• Chave Pix: CPF 442.802.418-56</li>
                  <li>• Mantenha o comprovante do Pix</li>
                </ul>
              </CardContent>
            </Card>
          </div>

          {/* Área de Depósito */}
          <div>
            <Card className="casino-card">
              <CardHeader>
                <CardTitle className="text-white text-center">
                  <QrCode className="w-8 h-8 mx-auto mb-2 text-blue-400" />
                  Dados para Depósito
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                
                {/* Valor mínimo */}
                <div className="text-center bg-blue-500/20 border border-blue-500/50 rounded-lg p-4">
                  <p className="text-blue-400 font-semibold">Depósito Mínimo</p>
                  <p className="text-3xl font-bold text-white">R$ {minDeposit},00</p>
                  <p className="text-sm text-gray-300">= 10 moedas para jogar</p>
                </div>

                {/* Chave Pix */}
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Chave Pix (CPF)
                  </label>
                  <div className="flex space-x-2">
                    <div className="flex-1 bg-gray-800 border border-gray-600 rounded-lg p-3">
                      <p className="text-white font-mono text-lg">{pixKey}</p>
                    </div>
                    <Button
                      onClick={copyPixKey}
                      className={`casino-button ${copied ? 'bg-green-500' : ''}`}
                    >
                      {copied ? (
                        <CheckCircle className="w-5 h-5" />
                      ) : (
                        <Copy className="w-5 h-5" />
                      )}
                    </Button>
                  </div>
                  {copied && (
                    <p className="text-green-400 text-sm mt-2">✓ Chave Pix copiada!</p>
                  )}
                </div>

                {/* Botão de confirmação */}
                <div className="space-y-4">
                  <Button
                    onClick={confirmDeposit}
                    disabled={isProcessing}
                    className="casino-button w-full h-12 text-lg"
                  >
                    {isProcessing ? (
                      <div className="flex items-center space-x-2">
                        <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                        <span>Processando...</span>
                      </div>
                    ) : (
                      'CONFIRMAR DEPÓSITO'
                    )}
                  </Button>
                  
                  <p className="text-xs text-gray-400 text-center">
                    Clique apenas após enviar o Pix
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DepositScreen;

