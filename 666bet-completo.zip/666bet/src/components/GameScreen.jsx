import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent } from '@/components/ui/card.jsx';
import { Coins, Settings, LogOut, Plus, Minus, Volume2, VolumeX } from 'lucide-react';

// Importar sons
import spinSound from '../assets/spin-sound.wav';
import winSound from '../assets/win-sound.wav';
import loseSound from '../assets/lose-sound.wav';

const GameScreen = ({ user, onLogout, onNavigate }) => {
  const [coins, setCoins] = useState(0);
  const [isSpinning, setIsSpinning] = useState(false);
  const [lastResult, setLastResult] = useState(null);
  const [totalWinnings, setTotalWinnings] = useState(0);
  const [spinCount, setSpinCount] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Carregar dados salvos
  useEffect(() => {
    const savedData = localStorage.getItem('666bet_gamedata');
    if (savedData) {
      const data = JSON.parse(savedData);
      setCoins(data.coins || 0);
      setTotalWinnings(data.totalWinnings || 0);
      setSpinCount(data.spinCount || 0);
    }
    
    // Carregar preferência de som
    const soundPref = localStorage.getItem('666bet_sound');
    if (soundPref !== null) {
      setSoundEnabled(JSON.parse(soundPref));
    }
  }, []);

  // Salvar dados
  const saveGameData = (newCoins, newWinnings, newSpinCount) => {
    const gameData = {
      coins: newCoins,
      totalWinnings: newWinnings,
      spinCount: newSpinCount,
      lastPlayed: new Date().toISOString()
    };
    localStorage.setItem('666bet_gamedata', JSON.stringify(gameData));
  };

  // Função para tocar sons
  const playSound = (soundFile) => {
    if (!soundEnabled) return;
    
    try {
      const audio = new Audio(soundFile);
      audio.volume = 0.5;
      audio.play().catch(e => console.log('Erro ao tocar som:', e));
    } catch (error) {
      console.log('Erro ao carregar som:', error);
    }
  };

  // Toggle do som
  const toggleSound = () => {
    const newSoundState = !soundEnabled;
    setSoundEnabled(newSoundState);
    localStorage.setItem('666bet_sound', JSON.stringify(newSoundState));
  };

  const spinRoulette = () => {
    if (coins < 1 || isSpinning) return;

    setIsSpinning(true);
    const newCoins = coins - 1;
    setCoins(newCoins);

    // Tocar som de giro
    playSound(spinSound);

    // Simular giro da roleta
    const rouletteWheel = document.querySelector('.roulette-wheel');
    if (rouletteWheel) {
      const randomRotation = Math.floor(Math.random() * 360) + 1800; // 5 voltas + posição aleatória
      rouletteWheel.style.transform = `rotate(${randomRotation}deg)`;
    }

    setTimeout(() => {
      // Determinar resultado (30% chance de ganhar)
      const isWin = Math.random() < 0.3;
      let winAmount = 0;
      
      if (isWin) {
        // Diferentes tipos de vitória
        const winType = Math.random();
        if (winType < 0.1) {
          winAmount = 10; // Jackpot pequeno (10%)
        } else if (winType < 0.3) {
          winAmount = 5; // Vitória média (20%)
        } else {
          winAmount = 2; // Vitória pequena (70%)
        }
        
        const finalCoins = newCoins + winAmount;
        setCoins(finalCoins);
        setTotalWinnings(totalWinnings + winAmount);
        setLastResult({ type: 'win', amount: winAmount });
        
        // Efeito de vitória
        createParticles();
        playWinAnimation();
        playSound(winSound);
      } else {
        setLastResult({ type: 'lose', amount: 1 });
        playLoseAnimation();
        playSound(loseSound);
      }

      const newSpinCount = spinCount + 1;
      setSpinCount(newSpinCount);
      saveGameData(newCoins + (winAmount || 0), totalWinnings + (winAmount || 0), newSpinCount);
      setIsSpinning(false);
    }, 3000);
  };

  const createParticles = () => {
    const container = document.querySelector('.particles-container');
    if (!container) return;

    for (let i = 0; i < 20; i++) {
      const particle = document.createElement('div');
      particle.className = 'particle';
      particle.style.left = Math.random() * 100 + '%';
      particle.style.animationDelay = Math.random() * 2 + 's';
      container.appendChild(particle);

      setTimeout(() => {
        particle.remove();
      }, 2000);
    }
  };

  const playWinAnimation = () => {
    const roulette = document.querySelector('.roulette-container');
    if (roulette) {
      roulette.classList.add('win-animation');
      setTimeout(() => roulette.classList.remove('win-animation'), 1000);
    }
  };

  const playLoseAnimation = () => {
    const roulette = document.querySelector('.roulette-container');
    if (roulette) {
      roulette.classList.add('lose-animation');
      setTimeout(() => roulette.classList.remove('lose-animation'), 500);
    }
  };

  const canWithdraw = totalWinnings >= 50;

  return (
    <div className="casino-bg min-h-screen">
      {/* Container de partículas */}
      <div className="particles-container fixed inset-0 pointer-events-none z-50"></div>
      
      {/* Header */}
      <div className="bg-black/50 backdrop-blur-sm border-b border-blue-500/30 p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold neon-text">666BET</h1>
            <span className="text-gray-400">Olá, {user.split('@')[0]}</span>
          </div>
          
          <div className="flex items-center space-x-4">
            <Button
              onClick={() => onNavigate('deposit')}
              className="casino-button"
              size="sm"
            >
              <Plus className="w-4 h-4 mr-2" />
              Depositar
            </Button>
            
            <Button
              onClick={() => onNavigate('withdraw')}
              disabled={!canWithdraw}
              className="casino-button"
              size="sm"
            >
              <Minus className="w-4 h-4 mr-2" />
              Sacar
            </Button>
            
            <Button
              onClick={toggleSound}
              variant="outline"
              size="sm"
              className={`border-blue-500 ${soundEnabled ? 'text-blue-400 hover:bg-blue-500' : 'text-gray-500 hover:bg-gray-500'} hover:text-white`}
              title={soundEnabled ? 'Desativar som' : 'Ativar som'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
            </Button>
            
            <Button
              onClick={onLogout}
              variant="outline"
              size="sm"
              className="border-red-500 text-red-500 hover:bg-red-500 hover:text-white"
            >
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Conteúdo Principal */}
      <div className="max-w-6xl mx-auto p-4 pt-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Painel de Informações */}
          <div className="lg:col-span-1 space-y-4">
            {/* Moedas */}
            <Card className="casino-card">
              <CardContent className="p-6">
                <div className="text-center">
                  <Coins className="w-12 h-12 text-yellow-500 mx-auto mb-2" />
                  <h3 className="text-lg font-semibold text-white mb-1">Suas Moedas</h3>
                  <p className="text-3xl font-bold neon-text">{coins}</p>
                  <p className="text-sm text-gray-400 mt-1">
                    {coins === 1 ? '1 giro disponível' : `${coins} giros disponíveis`}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Estatísticas */}
            <Card className="casino-card">
              <CardContent className="p-6">
                <h3 className="text-lg font-semibold text-white mb-4">Estatísticas</h3>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total de Giros:</span>
                    <span className="text-white font-semibold">{spinCount}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Total Ganho:</span>
                    <span className="text-green-400 font-semibold">R$ {totalWinnings.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Status Saque:</span>
                    <span className={canWithdraw ? "text-green-400" : "text-red-400"}>
                      {canWithdraw ? "Disponível" : "Indisponível"}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Último Resultado */}
            {lastResult && (
              <Card className="casino-card">
                <CardContent className="p-6">
                  <h3 className="text-lg font-semibold text-white mb-2">Último Resultado</h3>
                  <div className={`text-center p-4 rounded-lg ${
                    lastResult.type === 'win' 
                      ? 'bg-green-500/20 border border-green-500/50' 
                      : 'bg-red-500/20 border border-red-500/50'
                  }`}>
                    {lastResult.type === 'win' ? (
                      <>
                        <p className="text-green-400 font-bold text-xl">VITÓRIA!</p>
                        <p className="text-white">+{lastResult.amount} moedas</p>
                      </>
                    ) : (
                      <>
                        <p className="text-red-400 font-bold text-xl">TENTE NOVAMENTE</p>
                        <p className="text-white">-1 moeda</p>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Área da Roleta */}
          <div className="lg:col-span-2">
            <Card className="casino-card">
              <CardContent className="p-8">
                <div className="text-center">
                  <h2 className="text-3xl font-bold neon-text mb-8">ROLETA 666</h2>
                  
                  {/* Roleta */}
                  <div className="roulette-container mb-8">
                    <div className="roulette-pointer"></div>
                    <div className={`roulette-wheel ${isSpinning ? 'spinning' : ''}`}></div>
                  </div>

                  {/* Botão de Girar */}
                  <Button
                    onClick={spinRoulette}
                    disabled={coins < 1 || isSpinning}
                    className="casino-button text-xl px-12 py-4 h-auto"
                  >
                    {isSpinning ? (
                      <div className="flex items-center space-x-3">
                        <div className="w-6 h-6 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                        <span>GIRANDO...</span>
                      </div>
                    ) : coins < 1 ? (
                      'SEM MOEDAS'
                    ) : (
                      'GIRAR (1 MOEDA)'
                    )}
                  </Button>

                  {coins < 1 && (
                    <p className="text-yellow-400 mt-4 font-semibold">
                      Faça um depósito para continuar jogando!
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameScreen;

