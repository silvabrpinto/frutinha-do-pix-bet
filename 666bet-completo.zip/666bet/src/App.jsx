import { useState, useEffect } from 'react';
import Login from './components/Login.jsx';
import GameScreen from './components/GameScreen.jsx';
import DepositScreen from './components/DepositScreen.jsx';
import WithdrawScreen from './components/WithdrawScreen.jsx';
import './App.css';

function App() {
  const [currentScreen, setCurrentScreen] = useState('login');
  const [user, setUser] = useState(null);

  // Verificar se usuário já está logado
  useEffect(() => {
    const savedUser = localStorage.getItem('666bet_user');
    if (savedUser) {
      const userData = JSON.parse(savedUser);
      setUser(userData.email);
      setCurrentScreen('game');
    }
  }, []);

  const handleLogin = (email) => {
    setUser(email);
    setCurrentScreen('game');
  };

  const handleLogout = () => {
    localStorage.removeItem('666bet_user');
    setUser(null);
    setCurrentScreen('login');
  };

  const handleNavigate = (screen) => {
    setCurrentScreen(screen);
  };

  const handleBack = () => {
    setCurrentScreen('game');
  };

  // Renderizar tela baseada no estado atual
  const renderScreen = () => {
    switch (currentScreen) {
      case 'login':
        return <Login onLogin={handleLogin} />;
      
      case 'game':
        return (
          <GameScreen 
            user={user} 
            onLogout={handleLogout}
            onNavigate={handleNavigate}
          />
        );
      
      case 'deposit':
        return <DepositScreen onBack={handleBack} />;
      
      case 'withdraw':
        return <WithdrawScreen onBack={handleBack} />;
      
      default:
        return <Login onLogin={handleLogin} />;
    }
  };

  return (
    <div className="App">
      {renderScreen()}
    </div>
  );
}

export default App;

