# 666Bet - Aplicativo de Cassino Online

## 🎰 Sobre o Projeto

O **666Bet** é um aplicativo de cassino online completo com tema escuro e detalhes em azul neon, inspirado nos jogos de slot machine da PG Soft e no design moderno do stake.com. O aplicativo oferece uma experiência imersiva de roleta com sistema de moedas, depósito/saque via Pix e efeitos visuais e sonoros envolventes.

## ✨ Funcionalidades Principais

### 🔐 Sistema de Autenticação
- Tela de login simples e elegante
- Campos para e-mail e senha
- Autenticação local com localStorage
- Interface responsiva e moderna

### 🎮 Jogo Principal - Roleta 666
- Roleta visual com design profissional (cores vermelha/preta alternadas)
- Animações suaves de giro com efeitos CSS
- Sistema de randomização justo (30% chance de vitória)
- Diferentes tipos de prêmios (2, 5 ou 10 moedas)
- Feedback visual imediato para vitórias e derrotas

### 💰 Sistema de Moedas
- Cada giro custa 1 moeda
- Armazenamento local de progresso
- Estatísticas detalhadas (total de giros, ganhos, etc.)
- Sistema de saldo em tempo real

### 💳 Depósito via Pix
- Depósito mínimo: R$ 5,00
- Chave Pix: 442.802.418-56 (CPF)
- Cada depósito = 10 moedas
- Interface intuitiva com instruções passo a passo
- Botão de copiar chave Pix
- Confirmação automática de depósito

### 💸 Saque via Pix
- Saque mínimo: R$ 50,00
- Suporte a diferentes tipos de chave Pix (CPF, telefone, e-mail)
- Validação automática de valores
- Processamento em até 24 horas
- Interface clara com regras e informações

### 🎵 Efeitos Sonoros
- Som de giro da roleta com voz feminina
- Som de vitória personalizado
- Som de derrota motivacional
- Controle de volume integrado
- Preferências salvas localmente

### 📱 Design Responsivo
- Otimizado para dispositivos móveis
- Layout adaptativo para diferentes tamanhos de tela
- Botões grandes e acessíveis
- Navegação intuitiva
- Preparado para conversão em APK

## 🎨 Design e Tema

### Paleta de Cores
- **Fundo principal**: Preto (#0a0a0a)
- **Cards e elementos**: Cinza escuro (#1a1a1a)
- **Destaque principal**: Azul neon (#00d4ff)
- **Texto**: Branco (#ffffff)
- **Bordas**: Cinza médio (#333333)

### Efeitos Visuais
- Brilho neon em elementos importantes
- Animações suaves de transição
- Efeitos de partículas em vitórias
- Gradientes modernos
- Sombras e blur para profundidade

## 🛠️ Tecnologias Utilizadas

- **React 18** - Framework principal
- **Vite** - Build tool e dev server
- **Tailwind CSS** - Estilização
- **Shadcn/UI** - Componentes de interface
- **Lucide React** - Ícones
- **Framer Motion** - Animações (disponível)
- **LocalStorage** - Persistência de dados

## 📁 Estrutura do Projeto

```
666bet/
├── public/
├── src/
│   ├── assets/
│   │   ├── spin-sound.wav
│   │   ├── win-sound.wav
│   │   └── lose-sound.wav
│   ├── components/
│   │   ├── ui/
│   │   ├── Login.jsx
│   │   ├── GameScreen.jsx
│   │   ├── DepositScreen.jsx
│   │   └── WithdrawScreen.jsx
│   ├── App.jsx
│   ├── App.css
│   └── main.jsx
├── dist/ (build de produção)
└── README.md
```

## 🚀 Como Executar

### Desenvolvimento
```bash
cd 666bet
pnpm install
pnpm run dev
```

### Build de Produção
```bash
pnpm run build
```

### Preview da Build
```bash
pnpm run preview
```

## 📱 Preparação para APK

O projeto está totalmente preparado para ser convertido em APK usando ferramentas como:
- **Capacitor** (recomendado)
- **Cordova**
- **Tauri** (para desktop)

### Passos para APK:
1. Instalar Capacitor: `npm install @capacitor/core @capacitor/cli`
2. Inicializar: `npx cap init`
3. Adicionar Android: `npx cap add android`
4. Build: `npm run build`
5. Sync: `npx cap sync`
6. Abrir no Android Studio: `npx cap open android`

## 🎯 Funcionalidades Implementadas

### ✅ Completas
- [x] Tela de login responsiva
- [x] Sistema de autenticação local
- [x] Jogo de roleta funcional
- [x] Sistema de moedas
- [x] Depósito via Pix
- [x] Saque via Pix
- [x] Efeitos sonoros
- [x] Controle de volume
- [x] Responsividade mobile
- [x] Persistência de dados
- [x] Estatísticas de jogo
- [x] Animações e efeitos visuais
- [x] Tema escuro com azul neon

## 🔧 Configurações Importantes

### LocalStorage Keys
- `666bet_user` - Dados do usuário logado
- `666bet_gamedata` - Progresso do jogo (moedas, estatísticas)
- `666bet_sound` - Preferência de som
- `666bet_withdraw` - Solicitações de saque

### Configurações de Jogo
- **Custo por giro**: 1 moeda
- **Chance de vitória**: 30%
- **Prêmios possíveis**: 2, 5 ou 10 moedas
- **Depósito mínimo**: R$ 5,00 = 10 moedas
- **Saque mínimo**: R$ 50,00

## 🎮 Como Jogar

1. **Login**: Insira qualquer e-mail e senha
2. **Depósito**: Clique em "Depositar" e siga as instruções
3. **Jogar**: Use o botão "GIRAR" para apostar 1 moeda
4. **Ganhar**: Acumule ganhos para atingir o saque mínimo
5. **Sacar**: Solicite saque quando atingir R$ 50,00

## 🔒 Segurança e Privacidade

- Todos os dados são armazenados localmente
- Não há coleta de dados pessoais
- Chave Pix fornecida é fictícia para demonstração
- Sistema de autenticação é apenas para demonstração

## 📞 Suporte

Para dúvidas ou suporte técnico, entre em contato através dos canais oficiais do 666Bet.

---

**Desenvolvido com ❤️ para proporcionar a melhor experiência de cassino online**

